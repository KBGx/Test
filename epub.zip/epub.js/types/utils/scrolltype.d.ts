export default function scrollType(): string;

export function createDefiner(): Node;
